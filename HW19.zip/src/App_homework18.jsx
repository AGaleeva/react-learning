import Counter from "./components/Counter/Counter";

function App() {
  
  return (
    <div className="App">      
      <div>
        <Counter />   
      </div>      
    </div>
  );  
}

export default App;