import ProfileCard from "./ProfileCard";

export default ProfileCard;