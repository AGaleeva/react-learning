import Homework19 from "./Homework19";

export default Homework19;