import Lesson19 from "./Lesson19";

export default Lesson19;